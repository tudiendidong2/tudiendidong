package com.journaldev.recyclerviewcardview;


public class MyData {

    static String[] nameArray = {"Phố đi bộ Nguyễn Huệ", "Khu phố sang chảnh Saigon Garden", "Saigon Outcast", "Khu vui chơi giải trí Snow Town Sài Gòn", "Bắn cung đối kháng – quận 7", "Bảo tàng tranh 3D Artinus", "Khu du lịch BCR", "Khu du lịch suối Tiên", "Công viên cá Koi RinRin Park", "Công viên Vinhomes Central Park", " Địa đạo Củ Chi"};
    static String[] versionArray = {"Địa chỉ: Nguyễn Huệ, Quận 1.", "Địa chỉ: 99 Nguyễn Huệ, Quận 1.", "Địa chỉ: 118/1 Nguyễn Văn Hưởng, Thảo Điền, Quận 2.", "Địa chỉ: 125 đường Đồng Văn Cống, phường Thạnh Mỹ Lợi, Quận 2", "Địa chỉ: Hẻm 300 Nguyễn Văn Linh, Bình Thuận, Quận 7.7", "Địa chỉ: Số 2, đường số 9, Khu đô thị Him Lam, Tân Hưng, Quận 7.", "Địa chỉ: 191 đường Tam Đa, P.Trường Thạnh, Quận 9", "Địa chỉ: 120 Xa lộ Hà Nội, Phường Tân Phú, Quận 9.", "Địa chỉ: Trần Văn Mười, Hóc Môn, thành phố Hồ Chí Minh", "Địa chỉ: Vinhomes Central Park, phường 22, quận Bình Thạnh, thành phố Hồ Chí Minh", "Địa chỉ: Huyện Củ Chi, thành phố Hồ Chí Minh"};

    static Integer[] drawableArray = {R.drawable.nguyenhue, R.drawable.saigongarden, R.drawable.saigonqutcast,
            R.drawable.snowtown2, R.drawable.cungdoikhang, R.drawable.tranh3d, R.drawable.brc2,
            R.drawable.suoitien, R.drawable.rinrin, R.drawable.vinhomes, R.drawable.diadaocuchi};

    static Integer[] id_ = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
}
